config = {
  "fontSize": 1,
  "clickTab": 0,
  "displaySidebar": true,
  "colorTheme": 1
}
